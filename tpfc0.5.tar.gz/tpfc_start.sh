#!/bin/bash
gksu data/tp_fan_control
